# Engineering evidence

## Current validated evidence

- Test command: `PYTHONPATH=src python3 -m pytest -q`
- Result: 15 tests passed on 2026-09-17.
- Covered behavior: application discovery, deterministic evidence IDs, local/production planning, Kubernetes hardening, policy violation detection, secret placeholders, deployment approval/fail-closed execution, SLO evaluation, and benchmark provenance.
- Editable package build and install succeeded with `python3 -m pip install -e . --no-deps`.
- Installed entry point successfully analyzed the reference app and executed six policy checks against generated Kubernetes YAML.
- Repository-scan benchmark command: `cloudforge benchmark examples/reference-app --iterations 50`.
- Measured in this Work runner: 50 iterations, 13 evidence items; min 0.7361 ms, median 0.8227 ms, p95 1.7166 ms, max 2.9147 ms. Clock: `time.perf_counter_ns`. These numbers describe only this small pinned fixture and runner.
- No infrastructure was deployed in this run.
- No latency, throughput, recovery, or cost numbers are claimed.

This file records outcomes, not aspirations. Future evidence entries must name the exact procedure, environment, revision, and raw result artifact.
