from __future__ import annotations

import os
import time
from contextlib import asynccontextmanager

import psycopg
import redis.asyncio as redis
from fastapi import FastAPI, Response
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@postgres/app")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
REQUESTS = Counter("cloudforge_reference_requests_total", "Reference app requests", ["route", "status"])
LATENCY = Histogram("cloudforge_reference_request_seconds", "Reference app request latency", ["route"])


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.redis = redis.from_url(REDIS_URL, decode_responses=True)
    yield
    await app.state.redis.aclose()


app = FastAPI(title="CloudForge Reference App", lifespan=lifespan)
trace.set_tracer_provider(TracerProvider(resource=Resource.create({"service.name": "cloudforge-reference"})))
FastAPIInstrumentor.instrument_app(app)


@app.get("/health")
async def health():
    REQUESTS.labels("health", "ok").inc()
    return {"status": "ok", "version": os.getenv("APP_VERSION", "dev")}


@app.get("/ready")
async def ready():
    started = time.perf_counter()
    checks = {"postgres": False, "redis": False}
    try:
        with psycopg.connect(DATABASE_URL, connect_timeout=2) as connection:
            checks["postgres"] = connection.execute("SELECT 1").fetchone() == (1,)
    except psycopg.Error:
        pass
    try:
        checks["redis"] = bool(await app.state.redis.ping())
    except redis.RedisError:
        pass
    status = "ok" if all(checks.values()) else "degraded"
    LATENCY.labels("ready").observe(time.perf_counter() - started)
    REQUESTS.labels("ready", status).inc()
    return Response(content=__import__("json").dumps({"status": status, "checks": checks}), status_code=200 if status == "ok" else 503, media_type="application/json")


@app.post("/jobs/{payload}")
async def enqueue(payload: str):
    await app.state.redis.rpush("jobs", payload)
    REQUESTS.labels("jobs", "accepted").inc()
    return Response(content='{"status":"accepted"}', status_code=202, media_type="application/json")


@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

