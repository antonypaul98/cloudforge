import asyncio
import os

import redis.asyncio as redis


async def run() -> None:
    client = redis.from_url(os.getenv("REDIS_URL", "redis://redis:6379/0"), decode_responses=True)
    try:
        while True:
            item = await client.blpop("jobs", timeout=5)
            if item:
                await client.hincrby("job_results", item[1], 1)
    finally:
        await client.aclose()


if __name__ == "__main__":
    asyncio.run(run())

