# Security model

## Current controls

Generated Kubernetes workloads run as non-root, deny privilege escalation, drop Linux capabilities, use the runtime-default seccomp profile, request and limit resources, and include readiness/liveness probes. Environment values are secret references. Compose uses environment interpolation and requires the PostgreSQL password externally.

The built-in validator executes rules for YAML parsing, plaintext `Secret.stringData`, privileged containers, resource limits, health probes, and non-root pods.

## Trust boundaries

Repository content is untrusted input. The scanner reads text but never executes project code. Generated files are not applied. Cluster/cloud credentials are not required for analysis or generation. Future external scanners and deployment adapters must be subprocess-isolated, timeout-bound, and redact secrets.

## Known limitations

The current validator is intentionally small and is not a substitute for Kyverno/OPA, Trivy, Checkov, cloud IAM review, or admission control. Image provenance, signatures, network policies, TLS, RBAC, and supply-chain attestations remain future work.

