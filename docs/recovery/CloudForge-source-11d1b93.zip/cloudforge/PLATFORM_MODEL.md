# Platform model

Implemented entities:

- `ApplicationProfile`: root application aggregate.
- `Dependency`: typed database, cache, queue, or cloud SDK need.
- `HealthCheck`: application-declared health surface.
- `Evidence`: stable ID, source path, line, detail, confidence, and kind.
- `InfrastructureProposal`: environment-specific review object.
- `ProposedResource`: resource, reason, linked evidence, approval flag.
- `ValidationReport`: checks executed and structured findings.

Planned entities: Environment, Deployment, Resource, Policy, SLO, Incident, RecoveryAction, CostEstimate, BenchmarkRun, and EngineeringEvidenceReport.

The model serializes as portable YAML/JSON-compatible values. Evidence IDs are content-derived so identical inputs yield identical identities.

