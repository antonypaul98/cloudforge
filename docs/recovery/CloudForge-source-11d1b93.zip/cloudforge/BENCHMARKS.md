# Benchmarks

No runtime or recovery benchmark has been claimed yet because Docker/Kubernetes executables are not available in the current runner.

## Measured scanner baseline

On 2026-09-17, `cloudforge benchmark examples/reference-app --iterations 50` measured 50 deterministic scans of the pinned reference application. It found 13 evidence items per scan. Results in this runner were: min 0.7361 ms, median 0.8227 ms, p95 1.7166 ms, max 2.9147 ms, using `time.perf_counter_ns`. Raw machine-readable output is written to `.cloudforge/evidence/scan-benchmark.json` and is intentionally excluded from Git because it is run-specific.

Reproducible procedures planned:

- discovery latency: implemented via monotonic elapsed time for `cloudforge analyze` over a pinned fixture;
- generation correctness: generated artifact validation rate over fixture corpus;
- deployment and readiness: cluster event timestamps plus successful health probe;
- recovery: time from controlled pod deletion to replacement readiness;
- request latency: measured p50/p95/p99 from a fixed load profile;
- policy detection: known-positive and known-negative fixture accuracy.

Only measured outputs will be copied into `ENGINEERING_EVIDENCE.md`.
