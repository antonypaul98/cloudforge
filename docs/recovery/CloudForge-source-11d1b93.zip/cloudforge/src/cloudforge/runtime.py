from __future__ import annotations

import json
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Protocol


@dataclass(frozen=True)
class CommandEvidence:
    command: list[str]
    exit_code: int
    duration_seconds: float
    stdout: str
    stderr: str


@dataclass
class OperationEvidence:
    operation: str
    status: str
    approved: bool
    commands: list[CommandEvidence] = field(default_factory=list)
    measurements: dict[str, float | int | str | bool] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


class Executor(Protocol):
    def run(self, command: list[str], cwd: Path) -> CommandEvidence: ...


class SubprocessExecutor:
    def run(self, command: list[str], cwd: Path) -> CommandEvidence:
        started = time.monotonic()
        result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=300, check=False)
        return CommandEvidence(command, result.returncode, round(time.monotonic() - started, 6), result.stdout, result.stderr)


def deployment_plan(compose_file: Path) -> dict:
    return {
        "profile": "local",
        "compose_file": str(compose_file.resolve()),
        "commands": [["docker", "compose", "-f", str(compose_file.resolve()), "config"], ["docker", "compose", "-f", str(compose_file.resolve()), "up", "--build", "--detach", "--wait"]],
        "mutates_local_runtime": True,
        "requires_approval": True,
        "notice": "NO CHANGES HAVE BEEN APPLIED.",
    }


def deploy_local(compose_file: Path, approved: bool, executor: Executor | None = None) -> OperationEvidence:
    if not approved:
        return OperationEvidence("deploy-local", "approval-required", False)
    if executor is None and shutil.which("docker") is None:
        return OperationEvidence("deploy-local", "blocked-docker-not-found", True)
    runner = executor or SubprocessExecutor()
    evidence = OperationEvidence("deploy-local", "running", True)
    for command in deployment_plan(compose_file)["commands"]:
        result = runner.run(command, compose_file.parent)
        evidence.commands.append(result)
        if result.exit_code != 0:
            evidence.status = "failed"
            return evidence
    evidence.status = "deployed"
    return evidence


def verify_http(url: str, attempts: int = 10, interval: float = 1.0) -> OperationEvidence:
    evidence = OperationEvidence("verify-http", "failed", True)
    started = time.monotonic()
    for attempt in range(1, attempts + 1):
        try:
            request_started = time.monotonic()
            with urllib.request.urlopen(url, timeout=3) as response:
                body = response.read().decode(errors="replace")
                latency = time.monotonic() - request_started
                if 200 <= response.status < 300:
                    evidence.status = "verified"
                    evidence.measurements = {"attempts": attempt, "elapsed_seconds": round(time.monotonic() - started, 6), "last_latency_seconds": round(latency, 6), "http_status": response.status, "body": body[:1000]}
                    return evidence
        except (urllib.error.URLError, TimeoutError):
            pass
        if attempt < attempts:
            time.sleep(interval)
    evidence.measurements = {"attempts": attempts, "elapsed_seconds": round(time.monotonic() - started, 6)}
    return evidence


def write_operation_evidence(evidence: OperationEvidence, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(evidence.to_dict(), indent=2) + "\n")

