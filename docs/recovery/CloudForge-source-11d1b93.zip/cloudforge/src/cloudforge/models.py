from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


def _primitive(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {key: _primitive(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_primitive(item) for item in value]
    return value


@dataclass(frozen=True)
class Evidence:
    id: str
    kind: str
    path: str
    detail: str
    line: int | None = None
    confidence: Confidence = Confidence.HIGH


@dataclass(frozen=True)
class Dependency:
    name: str
    category: str
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True)
class HealthCheck:
    path: str
    evidence_ids: tuple[str, ...]


@dataclass
class ApplicationProfile:
    name: str
    root: str
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    runtime: str | None = None
    dependencies: list[Dependency] = field(default_factory=list)
    ports: list[int] = field(default_factory=list)
    health_checks: list[HealthCheck] = field(default_factory=list)
    environment_variables: list[str] = field(default_factory=list)
    workers: list[str] = field(default_factory=list)
    existing_iac: list[str] = field(default_factory=list)
    existing_ci: list[str] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return _primitive(asdict(self))


@dataclass(frozen=True)
class ProposedResource:
    kind: str
    name: str
    reason: str
    evidence_ids: tuple[str, ...]
    approval_required: bool = False


@dataclass
class InfrastructureProposal:
    application: str
    profile: str
    resources: list[ProposedResource]
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return _primitive(asdict(self))


@dataclass(frozen=True)
class Finding:
    rule_id: str
    severity: str
    message: str
    resource: str
    evidence: str


@dataclass
class ValidationReport:
    checks_executed: list[str] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(f.severity == "error" for f in self.findings)

    def to_dict(self) -> dict[str, Any]:
        return _primitive({"passed": self.passed, **asdict(self)})
