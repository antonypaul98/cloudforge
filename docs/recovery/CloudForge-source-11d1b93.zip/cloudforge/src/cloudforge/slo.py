from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal


@dataclass(frozen=True)
class SLOObjective:
    metric: Literal["availability", "p95_latency_ms", "error_rate"]
    operator: Literal[">=", "<="]
    target: float


@dataclass(frozen=True)
class SLOResult:
    objective: SLOObjective
    measured: float | None
    status: Literal["pass", "fail", "insufficient-data"]
    source: str

    def to_dict(self):
        return asdict(self)


def evaluate(objective: SLOObjective, measured: float | None, source: str) -> SLOResult:
    if measured is None:
        return SLOResult(objective, None, "insufficient-data", source)
    passed = measured >= objective.target if objective.operator == ">=" else measured <= objective.target
    return SLOResult(objective, measured, "pass" if passed else "fail", source)


def evaluate_all(config: dict, measurements: dict, source: str) -> list[SLOResult]:
    results = []
    for raw in config.get("objectives", []):
        objective = SLOObjective(raw["metric"], raw["operator"], float(raw["target"]))
        value = measurements.get(objective.metric)
        results.append(evaluate(objective, float(value) if value is not None else None, source))
    return results

