from __future__ import annotations

import json
import statistics
import time
from pathlib import Path

from .scanner import RepositoryScanner


def benchmark_scan(root: Path, iterations: int = 25) -> dict:
    if iterations < 1:
        raise ValueError("iterations must be positive")
    durations = []
    scanner = RepositoryScanner()
    evidence_count = 0
    for _ in range(iterations):
        started = time.perf_counter_ns()
        profile = scanner.scan(root)
        durations.append((time.perf_counter_ns() - started) / 1_000_000)
        evidence_count = len(profile.evidence)
    ordered = sorted(durations)
    percentile_index = lambda q: min(len(ordered) - 1, max(0, int((len(ordered) - 1) * q)))
    return {
        "benchmark": "repository-scan",
        "root": str(root.resolve()),
        "iterations": iterations,
        "evidence_count": evidence_count,
        "latency_ms": {
            "min": round(min(durations), 4),
            "median": round(statistics.median(durations), 4),
            "p95": round(ordered[percentile_index(0.95)], 4),
            "max": round(max(durations), 4),
        },
        "clock": "time.perf_counter_ns",
    }


def write_benchmark(result: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n")

