from __future__ import annotations

import hashlib
from pathlib import Path

from .models import Confidence, Evidence


def make_evidence(kind: str, root: Path, path: Path, detail: str, line: int | None = None,
                  confidence: Confidence = Confidence.HIGH) -> Evidence:
    relative = str(path.relative_to(root))
    identity = f"{kind}\0{relative}\0{line or ''}\0{detail}"
    evidence_id = "ev-" + hashlib.sha256(identity.encode()).hexdigest()[:12]
    return Evidence(evidence_id, kind, relative, detail, line, confidence)

