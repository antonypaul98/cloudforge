from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import ApplicationProfile, InfrastructureProposal


def _service_port(app: ApplicationProfile) -> int:
    return app.ports[0] if app.ports else 8000


def generate_local(app: ApplicationProfile, proposal: InfrastructureProposal, output: Path) -> list[Path]:
    output.mkdir(parents=True, exist_ok=True)
    port = _service_port(app)
    env = {key: f"${{{key}:-}}" for key in app.environment_variables}
    services: dict[str, Any] = {
        "app": {
            "build": {"context": str(Path(app.root).resolve())},
            "ports": [f"{port}:{port}"],
            "environment": env,
            "healthcheck": {"test": ["CMD", "python", "-c", f"import urllib.request; urllib.request.urlopen('http://localhost:{port}{app.health_checks[0].path if app.health_checks else '/health'}')"], "interval": "5s", "timeout": "3s", "retries": 10},
        }
    }
    names = {r.kind for r in proposal.resources}
    if "postgres-container" in names:
        services["postgres"] = {"image": "postgres:16-alpine", "environment": {"POSTGRES_PASSWORD": "${POSTGRES_PASSWORD:?set POSTGRES_PASSWORD}", "POSTGRES_DB": "app"}, "healthcheck": {"test": ["CMD-SHELL", "pg_isready -U postgres"], "interval": "5s", "timeout": "3s", "retries": 10}}
        services["app"]["depends_on"] = {"postgres": {"condition": "service_healthy"}}
    if "redis-container" in names:
        services["redis"] = {"image": "redis:7-alpine", "command": ["redis-server", "--appendonly", "yes"], "healthcheck": {"test": ["CMD", "redis-cli", "ping"], "interval": "5s", "timeout": "3s", "retries": 10}}
        services["app"].setdefault("depends_on", {})["redis"] = {"condition": "service_healthy"}
    compose = output / "compose.yaml"
    compose.write_text(yaml.safe_dump({"services": services}, sort_keys=False))
    return [compose]


def generate_kubernetes(app: ApplicationProfile, output: Path) -> list[Path]:
    output.mkdir(parents=True, exist_ok=True)
    port = _service_port(app)
    health = app.health_checks[0].path if app.health_checks else "/health"
    env = [{"name": key, "valueFrom": {"secretKeyRef": {"name": f"{app.name}-secrets", "key": key}}} for key in app.environment_variables]
    docs: list[dict[str, Any]] = [
        {"apiVersion": "apps/v1", "kind": "Deployment", "metadata": {"name": app.name, "labels": {"app.kubernetes.io/name": app.name}}, "spec": {"replicas": 2, "selector": {"matchLabels": {"app": app.name}}, "template": {"metadata": {"labels": {"app": app.name}}, "spec": {"securityContext": {"runAsNonRoot": True, "seccompProfile": {"type": "RuntimeDefault"}}, "containers": [{"name": "app", "image": f"{app.name}:local", "ports": [{"containerPort": port}], "env": env, "resources": {"requests": {"cpu": "100m", "memory": "128Mi"}, "limits": {"cpu": "500m", "memory": "512Mi"}}, "securityContext": {"allowPrivilegeEscalation": False, "capabilities": {"drop": ["ALL"]}, "readOnlyRootFilesystem": True}, "readinessProbe": {"httpGet": {"path": health, "port": port}, "periodSeconds": 5}, "livenessProbe": {"httpGet": {"path": health, "port": port}, "periodSeconds": 10}}]}}}},
        {"apiVersion": "v1", "kind": "Service", "metadata": {"name": app.name}, "spec": {"selector": {"app": app.name}, "ports": [{"port": 80, "targetPort": port}]}},
    ]
    target = output / "kubernetes.yaml"
    target.write_text(yaml.safe_dump_all(docs, sort_keys=False))
    return [target]

