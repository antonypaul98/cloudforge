"""CloudForge: evidence-first platform engineering."""

__version__ = "0.1.0"

