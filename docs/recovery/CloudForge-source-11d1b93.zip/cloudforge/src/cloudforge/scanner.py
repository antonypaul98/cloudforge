from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path

import yaml

from .evidence import make_evidence
from .models import ApplicationProfile, Dependency, HealthCheck

IGNORED = {".git", ".venv", "venv", "node_modules", "dist", "build", "__pycache__"}
ENV_PATTERN = re.compile(r"(?:os\.(?:getenv|environ\.get)|environ\[)\(?[\"']([A-Z][A-Z0-9_]*)")
PORT_PATTERNS = [re.compile(r"EXPOSE\s+(\d+)", re.I), re.compile(r"--port(?:=|\s+)(\d+)")]
HEALTH_PATTERN = re.compile(r"(?:@\w+\.(?:get|route)|add_api_route)\(\s*[\"']([^\"']*(?:health|ready|live)[^\"']*)", re.I)


class RepositoryScanner:
    def scan(self, root: Path) -> ApplicationProfile:
        root = root.resolve()
        profile = ApplicationProfile(name=root.name, root=str(root))
        files = sorted(p for p in root.rglob("*") if p.is_file() and not IGNORED.intersection(p.parts))
        evidence_by_id = {}

        def add(ev):
            evidence_by_id[ev.id] = ev
            return ev.id

        py_files = [p for p in files if p.suffix == ".py"]
        if py_files:
            ev = make_evidence("language", root, py_files[0], "Python source file detected")
            add(ev); profile.languages.append("Python")

        package_json = next((p for p in files if p.name == "package.json"), None)
        if package_json:
            try:
                node_manifest = json.loads(package_json.read_text())
                node_dependencies = {**node_manifest.get("dependencies", {}), **node_manifest.get("devDependencies", {})}
                add(make_evidence("language", root, package_json, "Node.js package manifest detected"))
                profile.languages.append("JavaScript/TypeScript")
                if "express" in node_dependencies:
                    add(make_evidence("framework", root, package_json, "express dependency declared"))
                    profile.frameworks.append("Express")
            except (json.JSONDecodeError, OSError):
                pass

        dependencies: dict[tuple[str, str], set[str]] = {}
        manifests = [p for p in files if p.name in {"pyproject.toml", "requirements.txt"}]
        packages: set[str] = set()
        for manifest in manifests:
            if manifest.name == "pyproject.toml":
                try:
                    data = tomllib.loads(manifest.read_text())
                    raw = data.get("project", {}).get("dependencies", [])
                    packages.update(re.split(r"[<>=!~\[]", x, 1)[0].strip().lower() for x in raw)
                    py_req = data.get("project", {}).get("requires-python")
                    if py_req:
                        profile.runtime = f"Python {py_req}"
                        add(make_evidence("runtime", root, manifest, f"requires-python = {py_req}"))
                except (tomllib.TOMLDecodeError, OSError):
                    pass
            else:
                for line_no, line in enumerate(manifest.read_text(errors="ignore").splitlines(), 1):
                    pkg = re.split(r"[<>=!~\[]", line, 1)[0].strip().lower()
                    if pkg and not pkg.startswith("#"):
                        packages.add(pkg)

        if "fastapi" in packages:
            eid = add(make_evidence("framework", root, manifests[0], "fastapi dependency declared"))
            profile.frameworks.append("FastAPI")
        package_map = {
            "psycopg": ("PostgreSQL", "database"), "psycopg2": ("PostgreSQL", "database"),
            "asyncpg": ("PostgreSQL", "database"), "redis": ("Redis", "cache"),
            "celery": ("Celery", "queue"), "boto3": ("AWS", "cloud-sdk"),
        }
        for pkg in sorted(packages):
            if pkg in package_map:
                name, category = package_map[pkg]
                eid = add(make_evidence("dependency", root, manifests[0], f"{pkg} dependency declared"))
                dependencies.setdefault((name, category), set()).add(eid)

        for path in files:
            if path.name == "Dockerfile" or path.name.startswith("Dockerfile."):
                profile.existing_iac.append(str(path.relative_to(root)))
                add(make_evidence("container", root, path, "Dockerfile detected"))
            if path.name in {"compose.yaml", "compose.yml", "docker-compose.yaml", "docker-compose.yml"}:
                profile.existing_iac.append(str(path.relative_to(root)))
                add(make_evidence("iac", root, path, "Docker Compose configuration detected"))
            if path.suffix in {".tf", ".tf.json"}:
                profile.existing_iac.append(str(path.relative_to(root)))
                add(make_evidence("iac", root, path, "Terraform/OpenTofu configuration detected"))
            if ".github/workflows" in str(path).replace("\\", "/") and path.suffix in {".yml", ".yaml"}:
                profile.existing_ci.append(str(path.relative_to(root)))
                add(make_evidence("ci", root, path, "GitHub Actions workflow detected"))
            if path.suffix not in {".py", ".yml", ".yaml", ".toml", ".txt", ""}:
                continue
            try:
                text = path.read_text(errors="ignore")
            except OSError:
                continue
            worker_signals = ("blpop(", "celery.task", "@shared_task", "rq.Worker", "dramatiq.actor")
            if path.suffix == ".py" and ("worker" in path.stem.lower() or any(signal in text for signal in worker_signals)):
                relative = str(path.relative_to(root))
                if relative not in profile.workers:
                    profile.workers.append(relative)
                    add(make_evidence("worker", root, path, "Background worker signal detected"))
            for line_no, line in enumerate(text.splitlines(), 1):
                for match in ENV_PATTERN.finditer(line):
                    key = match.group(1)
                    if key not in profile.environment_variables:
                        profile.environment_variables.append(key)
                        add(make_evidence("environment", root, path, f"Environment variable {key} referenced", line_no))
                for pattern in PORT_PATTERNS:
                    match = pattern.search(line)
                    if match and int(match.group(1)) not in profile.ports:
                        port = int(match.group(1)); profile.ports.append(port)
                        add(make_evidence("port", root, path, f"Port {port} declared", line_no))
                match = HEALTH_PATTERN.search(line)
                if match:
                    eid = add(make_evidence("health", root, path, f"Health route {match.group(1)} declared", line_no))
                    if not any(h.path == match.group(1) for h in profile.health_checks):
                        profile.health_checks.append(HealthCheck(match.group(1), (eid,)))

        env_dependency_map = {
            "DATABASE_URL": ("PostgreSQL", "database"),
            "REDIS_URL": ("Redis", "cache"),
        }
        for ev in evidence_by_id.values():
            if ev.kind == "environment":
                key = ev.detail.split()[2]
                if key in env_dependency_map:
                    name, category = env_dependency_map[key]
                    dependencies.setdefault((name, category), set()).add(ev.id)

        profile.dependencies = [Dependency(name, category, tuple(sorted(ids))) for (name, category), ids in sorted(dependencies.items())]
        profile.ports.sort(); profile.environment_variables.sort(); profile.workers.sort(); profile.existing_iac.sort(); profile.existing_ci.sort()
        profile.evidence = sorted(evidence_by_id.values(), key=lambda x: x.id)
        return profile


def dump_profile(profile: ApplicationProfile, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(profile.to_dict(), sort_keys=False))
