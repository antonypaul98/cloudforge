from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import Finding, ValidationReport


def _containers(document: dict[str, Any]) -> list[dict[str, Any]]:
    if document.get("kind") == "Pod":
        return document.get("spec", {}).get("containers", [])
    return document.get("spec", {}).get("template", {}).get("spec", {}).get("containers", [])


def validate_kubernetes(path: Path) -> ValidationReport:
    report = ValidationReport(checks_executed=["yaml-parse", "no-plaintext-secret", "no-privileged-container", "resource-limits", "health-probes", "non-root"])
    try:
        documents = [d for d in yaml.safe_load_all(path.read_text()) if d]
    except yaml.YAMLError as exc:
        report.findings.append(Finding("CF000", "error", f"Invalid YAML: {exc}", str(path), "parser"))
        return report
    for index, doc in enumerate(documents):
        kind = doc.get("kind", "Unknown")
        name = doc.get("metadata", {}).get("name", f"document-{index}")
        resource = f"{kind}/{name}"
        if kind == "Secret" and "stringData" in doc:
            report.findings.append(Finding("CF101", "error", "Plaintext stringData is forbidden", resource, "stringData"))
        for container in _containers(doc):
            cname = container.get("name", "unnamed")
            security = container.get("securityContext", {})
            if security.get("privileged") is True:
                report.findings.append(Finding("CF102", "error", "Privileged containers are forbidden", resource, cname))
            if not container.get("resources", {}).get("limits"):
                report.findings.append(Finding("CF103", "error", "Container resource limits are required", resource, cname))
            if not container.get("readinessProbe") or not container.get("livenessProbe"):
                report.findings.append(Finding("CF104", "error", "Readiness and liveness probes are required", resource, cname))
        if _containers(doc):
            pod_security = doc.get("spec", {}).get("template", {}).get("spec", {}).get("securityContext", {})
            if pod_security.get("runAsNonRoot") is not True:
                report.findings.append(Finding("CF105", "error", "Pod must run as non-root", resource, "spec.template.spec.securityContext"))
    return report

