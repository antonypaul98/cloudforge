from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

from .benchmark import benchmark_scan, write_benchmark
from .generator import generate_kubernetes, generate_local
from .planner import build_proposal
from .policy import validate_kubernetes
from .runtime import deploy_local, deployment_plan, verify_http, write_operation_evidence
from .slo import evaluate_all
from .scanner import RepositoryScanner, dump_profile


def _write_yaml(data, path: Path | None) -> None:
    rendered = yaml.safe_dump(data, sort_keys=False)
    if path:
        path.parent.mkdir(parents=True, exist_ok=True); path.write_text(rendered)
    print(rendered, end="")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cloudforge", description="Evidence-first platform engineering")
    subs = parser.add_subparsers(dest="command", required=True)
    analyze = subs.add_parser("analyze"); analyze.add_argument("path", nargs="?", default="."); analyze.add_argument("--output", type=Path)
    plan = subs.add_parser("plan"); plan.add_argument("path", nargs="?", default="."); plan.add_argument("--profile", choices=["local", "small", "production"], default="local"); plan.add_argument("--output", type=Path)
    generate = subs.add_parser("generate"); generate.add_argument("path", nargs="?", default="."); generate.add_argument("--profile", choices=["local", "kubernetes"], default="local"); generate.add_argument("--output", type=Path, default=Path(".cloudforge/generated"))
    validate = subs.add_parser("validate"); validate.add_argument("path", type=Path, nargs="?", default=Path(".cloudforge/generated/kubernetes.yaml")); validate.add_argument("--json", action="store_true")
    deploy = subs.add_parser("deploy"); deploy.add_argument("--compose", type=Path, default=Path(".cloudforge/generated/local/compose.yaml")); deploy.add_argument("--approve", action="store_true"); deploy.add_argument("--evidence", type=Path, default=Path(".cloudforge/evidence/deploy.json"))
    verify = subs.add_parser("verify"); verify.add_argument("--url", default="http://localhost:8000/health"); verify.add_argument("--attempts", type=int, default=10); verify.add_argument("--evidence", type=Path, default=Path(".cloudforge/evidence/verify.json"))
    benchmark = subs.add_parser("benchmark"); benchmark.add_argument("path", nargs="?", default="."); benchmark.add_argument("--iterations", type=int, default=25); benchmark.add_argument("--output", type=Path, default=Path(".cloudforge/evidence/scan-benchmark.json"))
    slo = subs.add_parser("slo"); slo.add_argument("config", type=Path); slo.add_argument("measurements", type=Path); slo.add_argument("--source", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "analyze":
        app = RepositoryScanner().scan(Path(args.path)); _write_yaml(app.to_dict(), args.output); return 0
    if args.command == "plan":
        app = RepositoryScanner().scan(Path(args.path)); proposal = build_proposal(app, args.profile); _write_yaml(proposal.to_dict(), args.output); return 0
    if args.command == "generate":
        app = RepositoryScanner().scan(Path(args.path)); proposal = build_proposal(app, "local" if args.profile == "local" else "production")
        created = generate_local(app, proposal, args.output) if args.profile == "local" else generate_kubernetes(app, args.output)
        print("Generated reviewable artifacts; no changes have been applied:")
        for item in created: print(f"- {item}")
        return 0
    if args.command == "validate":
        report = validate_kubernetes(args.path)
        print(json.dumps(report.to_dict(), indent=2) if args.json else yaml.safe_dump(report.to_dict(), sort_keys=False), end="\n")
        return 0 if report.passed else 2
    if args.command == "deploy":
        if not args.approve:
            print(yaml.safe_dump(deployment_plan(args.compose), sort_keys=False), end="")
            return 3
        evidence = deploy_local(args.compose, True)
        write_operation_evidence(evidence, args.evidence)
        print(json.dumps(evidence.to_dict(), indent=2))
        return 0 if evidence.status == "deployed" else 4
    if args.command == "verify":
        evidence = verify_http(args.url, args.attempts)
        write_operation_evidence(evidence, args.evidence)
        print(json.dumps(evidence.to_dict(), indent=2))
        return 0 if evidence.status == "verified" else 5
    if args.command == "benchmark":
        result = benchmark_scan(Path(args.path), args.iterations)
        write_benchmark(result, args.output)
        print(json.dumps(result, indent=2))
        return 0
    if args.command == "slo":
        config = yaml.safe_load(args.config.read_text())
        measurements = json.loads(args.measurements.read_text())
        results = evaluate_all(config, measurements, args.source)
        print(yaml.safe_dump({"results": [item.to_dict() for item in results]}, sort_keys=False), end="")
        return 0 if all(item.status == "pass" for item in results) else 6
    return 1


if __name__ == "__main__":
    sys.exit(main())
