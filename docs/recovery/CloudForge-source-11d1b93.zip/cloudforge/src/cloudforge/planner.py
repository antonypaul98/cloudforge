from __future__ import annotations

from .models import ApplicationProfile, InfrastructureProposal, ProposedResource


def build_proposal(app: ApplicationProfile, profile: str = "local") -> InfrastructureProposal:
    if profile not in {"local", "small", "production"}:
        raise ValueError(f"unsupported profile: {profile}")
    resources: list[ProposedResource] = []
    runtime_evidence = tuple(e.id for e in app.evidence if e.kind in {"language", "framework", "container"})
    if app.languages or app.frameworks:
        kind = "docker-compose-service" if profile == "local" else "kubernetes-deployment"
        resources.append(ProposedResource(kind, app.name, "Runnable application service detected", runtime_evidence))
        if profile != "local":
            resources.append(ProposedResource("kubernetes-service", app.name, "Expose the workload inside the cluster", runtime_evidence))
    for dep in app.dependencies:
        if dep.category == "database":
            kind = "postgres-container" if profile == "local" else "managed-postgresql"
            resources.append(ProposedResource(kind, dep.name.lower(), "Database dependency detected", dep.evidence_ids, profile != "local"))
        elif dep.category == "cache":
            kind = "redis-container" if profile == "local" else "managed-redis"
            resources.append(ProposedResource(kind, dep.name.lower(), "Cache dependency detected", dep.evidence_ids, profile != "local"))
    warnings = []
    if not app.health_checks:
        warnings.append("No health endpoint was detected; deployment verification will be incomplete.")
    if profile == "production":
        warnings.append("Production resources are proposals only and require explicit human approval.")
    return InfrastructureProposal(app.name, profile, resources, warnings)

