# Architecture

The first vertical slice is deliberately deterministic.

1. `RepositoryScanner` reads manifests and source/configuration patterns.
2. `ApplicationProfile` stores canonical facts and stable evidence IDs.
3. `build_proposal` maps facts to the smallest deployment profile.
4. Generators produce reviewable Compose or Kubernetes configuration.
5. The policy engine parses generated objects and executes named controls.
6. Future deployment adapters consume only approved, validated plans.
7. Verification and chaos adapters will record measured outcomes as evidence.

AI is outside the trusted decision kernel. A future interpretation adapter may add low-confidence annotations, but deterministic evidence and policy gates remain authoritative.

