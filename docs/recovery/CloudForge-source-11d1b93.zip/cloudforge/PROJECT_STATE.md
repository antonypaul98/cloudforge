# Project state

Updated: 2026-09-17

## Current checkpoint

Checkpoint 19 is partially complete. The safe local deployment adapter and approval gate are implemented and tested; real deployment is blocked by the absence of Docker in the current runner.

## Completed checkpoints

1. Market/open-source/job-signal research
2. White-space analysis
3. Product specification
4. Repository foundation
5. Application model
6. Repository scanner
7. Python/FastAPI detection
8. PostgreSQL/Redis dependency detection
9. Docker analysis
10. Infrastructure planner
11. Evidence/provenance system
12. Local deployment profile
13. Docker Compose generation
14. Kubernetes generation
15. Configuration validation
16. Policy engine
17. Secrets validation
18. Instrumented reference application

Additional implemented foundations: HTTP health verification, SLO model/evaluator, reproducible discovery benchmark, Node/Express/Compose/CI/background-worker detection, and GitHub Actions CI.

## Acceptance evidence

`PYTHONPATH=src python3 -m pytest -q` completed successfully with 15 passing tests. Editable packaging succeeded. The installed entry point analyzed the reference application and generated Kubernetes configuration passed all six executed built-in policy checks. A 50-iteration scanner benchmark measured median 0.8227 ms and p95 1.7166 ms for the pinned reference fixture in this runner.

## Architecture decisions

- Evidence-first verification plane, not a Heroku or portal clone.
- Deterministic scanner and planner form the trusted kernel.
- AI remains optional/advisory and cannot apply changes.
- Small/local applications use Compose; Kubernetes is profile-specific.
- Generated configuration contains references, never plaintext production secrets.

## Limitations and blockers

- The current runner has no Docker, kubectl, kind, Terraform, or OpenTofu executable; the real approved deployment preflight correctly recorded `blocked-docker-not-found`, and no deployment or IaC validation is claimed.
- Scanner support is intentionally narrow and needs more fixtures.
- The built-in policy set is a bootstrap, not admission-control parity.

## Exact next checkpoint

Run the already-implemented approved deployment adapter in a Docker-capable environment, verify `/health` and `/ready`, retain command/HTTP evidence, then add a disposable kind cluster and measured pod-recovery experiment.
