# Master specification

## Product contract

CloudForge follows `discover → model → propose → validate → generate → plan → approve → deploy → verify → observe`. Proposal and application are distinct operations. Production mutation always requires an explicit approval boundary.

## Differentiating thesis

CloudForge is not a portal, hosted PaaS, or natural-language Terraform generator. It is an evidence and verification plane over existing tools. Its durable artifact is a chain from repository fact to infrastructure decision to validated configuration to measured runtime and recovery evidence.

## MVP acceptance

The MVP is complete when the reference application can be deterministically inspected, represented canonically, mapped to a minimal local plan, generated as Compose and Kubernetes artifacts, validated, deployed to a disposable local cluster, health-checked, observed, disrupted by a scoped pod kill, and verified to recover with measured times.

## Safety invariants

- No implicit apply.
- No plaintext production secrets in generated Git artifacts.
- No production chaos without explicit authorization.
- AI output is labeled as hypothesis or recommendation.
- PASS and benchmark numbers require retained command/result evidence.

