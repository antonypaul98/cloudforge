# Roadmap

## Phase 1 — evidence-first discovery and generation

- [x] Market and white-space research
- [x] Product specification and repository foundation
- [x] Canonical application/evidence model
- [x] Python, FastAPI, PostgreSQL, Redis, Docker, port, environment, and health discovery
- [x] Local/production-aware infrastructure proposal
- [x] Docker Compose and hardened Kubernetes generation
- [x] Built-in deterministic policy engine
- [x] Instrumented reference application
- [ ] Expand detection fixtures for Node, workers, cron, storage, queues, Compose, Terraform, and Helm

## Phase 2 — verified local runtime

- [ ] Docker build and Compose deployment adapter
- [ ] kind/k3d adapter
- [ ] readiness/dependency verification
- [ ] OpenTelemetry Collector + Prometheus configuration
- [ ] SLO evaluation
- [ ] scoped pod-failure experiment
- [ ] measured recovery evidence

## Phase 3 — infrastructure and delivery

- [ ] OpenTofu AWS generation and static validation
- [ ] Trivy/Checkov/Kyverno adapters
- [ ] GitOps export
- [ ] sourced cost estimates
- [ ] canary/rollback verification
- [ ] evidence report generator and release hardening

