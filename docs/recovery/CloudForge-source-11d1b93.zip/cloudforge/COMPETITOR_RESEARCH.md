# Ecosystem and white-space research

Research performed 2026-09-17 against official documentation, project repositories, industry material, and current product documentation.

## What is commoditized

- Service catalogs, templates, and developer portals: Backstage, Port.
- Resource abstraction/orchestration: Crossplane and Humanitec.
- Declarative infrastructure lifecycle: Terraform/OpenTofu and Pulumi.
- Kubernetes reconciliation and packaging: Kubernetes, Helm, operators.
- GitOps reconciliation: Argo CD and Flux; promotion workflows are extending through Kargo/Argo Rollouts.
- Push-to-deploy PaaS experience: Railway, Render, Fly.io, Vercel, Qovery.
- Metrics, dashboards, and telemetry plumbing: Prometheus, Grafana, OpenTelemetry.
- Policy/security primitives: OPA, Kyverno, Trivy, Falco.
- Kubernetes fault injection: Chaos Mesh and LitmusChaos.

Rebuilding any one category would produce a weaker clone.

## Problems that remain

Teams still translate repository facts into platform contracts manually; struggle to explain why resources exist; confuse a successful apply with a working application; keep plan, policy, telemetry, chaos, and recovery evidence in separate systems; and cannot reliably distinguish observed facts from AI guesses. Smaller teams also face an all-or-nothing jump from simple hosting to Kubernetes-heavy IDPs.

## Product direction

CloudForge is an evidence-and-verification layer. It deterministically derives an application model, selects the smallest profile, generates artifacts for existing ecosystems, validates policy, then records application and recovery verification. This chain is the white space: `repository evidence → decision rationale → plan → approval → runtime evidence → recovery proof`.

AI is useful for ambiguous source interpretation, incident summarization, candidate remediation, and plain-language explanation. AI is unacceptable as the sole authority for credentials, IAM, networking exposure, destructive changes, production chaos, cost claims, or remediation application.

## Job-signal mapping

Recurring platform/SRE evidence should exercise Linux, Python/Go, AWS, Docker, Kubernetes, Terraform/OpenTofu, Helm, GitHub Actions, GitOps, OpenTelemetry, Prometheus/Grafana, security/policy, incident response, SLOs, and cost. CloudForge demonstrates those skills only when a real adapter/test/evidence artifact exists; documentation alone does not count.

## Sources inspected

- [Backstage documentation](https://backstage.io/docs/overview/what-is-backstage)
- [Crossplane documentation](https://docs.crossplane.io/latest/)
- [Humanitec documentation](https://developer.humanitec.com/)
- [Port documentation](https://docs.port.io/)
- [OpenTofu documentation](https://opentofu.org/docs/intro/)
- [Kubernetes concepts](https://kubernetes.io/docs/concepts/overview/)
- [OpenTelemetry documentation](https://opentelemetry.io/docs/)
- [Prometheus documentation](https://prometheus.io/docs/introduction/overview/)
- [OPA documentation](https://www.openpolicyagent.org/docs)
- [Kyverno documentation](https://kyverno.io/docs/introduction/)
- [Chaos Mesh repository](https://github.com/chaos-mesh/chaos-mesh)
- [CNCF 2024 annual survey](https://www.cncf.io/reports/cncf-annual-survey-2024/)

