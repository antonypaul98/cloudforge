from pathlib import Path

import yaml

from cloudforge.cli import main


def test_analyze_writes_serializable_yaml(tmp_path: Path):
    app = tmp_path / "app"
    app.mkdir()
    (app / "requirements.txt").write_text("fastapi\n")
    (app / "main.py").write_text('import os\nTOKEN=os.getenv("API_TOKEN")\n')
    output = tmp_path / "application.yaml"
    assert main(["analyze", str(app), "--output", str(output)]) == 0
    parsed = yaml.safe_load(output.read_text())
    assert parsed["evidence"]
    assert {item["confidence"] for item in parsed["evidence"]} == {"high"}
