from pathlib import Path

from cloudforge.runtime import CommandEvidence, deploy_local, deployment_plan


class FakeExecutor:
    def __init__(self, exit_codes=(0, 0)):
        self.exit_codes = iter(exit_codes)
        self.commands = []

    def run(self, command, cwd):
        self.commands.append(command)
        code = next(self.exit_codes)
        return CommandEvidence(command, code, 0.01, "ok" if code == 0 else "", "" if code == 0 else "failed")


def test_deployment_requires_approval(tmp_path: Path):
    compose = tmp_path / "compose.yaml"
    compose.write_text("services: {}\n")
    executor = FakeExecutor()
    result = deploy_local(compose, approved=False, executor=executor)
    assert result.status == "approval-required"
    assert executor.commands == []
    assert deployment_plan(compose)["notice"] == "NO CHANGES HAVE BEEN APPLIED."


def test_approved_deployment_validates_then_applies(tmp_path: Path):
    compose = tmp_path / "compose.yaml"
    compose.write_text("services: {}\n")
    executor = FakeExecutor()
    result = deploy_local(compose, approved=True, executor=executor)
    assert result.status == "deployed"
    assert executor.commands[0][-1] == "config"
    assert executor.commands[1][-3:] == ["--build", "--detach", "--wait"]


def test_failed_config_does_not_apply(tmp_path: Path):
    compose = tmp_path / "compose.yaml"
    compose.write_text("services: [\n")
    executor = FakeExecutor((1,))
    result = deploy_local(compose, approved=True, executor=executor)
    assert result.status == "failed"
    assert len(executor.commands) == 1
