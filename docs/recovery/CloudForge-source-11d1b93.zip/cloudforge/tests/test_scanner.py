from pathlib import Path

from cloudforge.scanner import RepositoryScanner


def test_detects_fastapi_dependencies_and_evidence(tmp_path: Path):
    (tmp_path / "pyproject.toml").write_text('[project]\nrequires-python=">=3.11"\ndependencies=["fastapi", "psycopg[binary]", "redis"]\n')
    (tmp_path / "app.py").write_text('import os\nDATABASE_URL=os.getenv("DATABASE_URL")\nREDIS_URL=os.getenv("REDIS_URL")\n@app.get("/health")\ndef health(): return {}\n')
    (tmp_path / "Dockerfile").write_text("FROM python:3.12\nEXPOSE 8000\n")
    app = RepositoryScanner().scan(tmp_path)
    assert app.frameworks == ["FastAPI"]
    assert [(d.name, d.category) for d in app.dependencies] == [("PostgreSQL", "database"), ("Redis", "cache")]
    assert app.ports == [8000]
    assert app.health_checks[0].path == "/health"
    assert {"DATABASE_URL", "REDIS_URL"} == set(app.environment_variables)
    assert all(dep.evidence_ids for dep in app.dependencies)


def test_evidence_ids_are_deterministic(tmp_path: Path):
    (tmp_path / "main.py").write_text('import os\nX=os.getenv("DATABASE_URL")\n')
    scanner = RepositoryScanner()
    first = scanner.scan(tmp_path)
    second = scanner.scan(tmp_path)
    assert [e.id for e in first.evidence] == [e.id for e in second.evidence]


def test_detects_node_compose_ci_and_worker(tmp_path: Path):
    (tmp_path / "package.json").write_text('{"dependencies":{"express":"^5.0.0"}}')
    (tmp_path / "worker.py").write_text("async def run(client):\n    return await client.blpop('jobs')\n")
    (tmp_path / "compose.yaml").write_text("services: {}\n")
    workflow = tmp_path / ".github" / "workflows"
    workflow.mkdir(parents=True)
    (workflow / "ci.yml").write_text("name: CI\n")
    app = RepositoryScanner().scan(tmp_path)
    assert "JavaScript/TypeScript" in app.languages
    assert "Express" in app.frameworks
    assert app.workers == ["worker.py"]
    assert app.existing_iac == ["compose.yaml"]
    assert app.existing_ci == [".github/workflows/ci.yml"]
