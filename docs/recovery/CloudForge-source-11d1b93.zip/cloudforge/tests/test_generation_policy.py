from pathlib import Path

import yaml

from cloudforge.generator import generate_kubernetes, generate_local
from cloudforge.planner import build_proposal
from cloudforge.policy import validate_kubernetes
from cloudforge.scanner import RepositoryScanner


def fixture_app(tmp_path: Path):
    (tmp_path / "requirements.txt").write_text("fastapi\npsycopg\nredis\n")
    (tmp_path / "main.py").write_text('import os\nA=os.getenv("DATABASE_URL")\nB=os.getenv("REDIS_URL")\n@app.get("/health")\ndef h(): return {}\n')
    (tmp_path / "Dockerfile").write_text("FROM python:3.12\nEXPOSE 8000\n")
    return RepositoryScanner().scan(tmp_path)


def test_generated_kubernetes_passes_builtin_policy(tmp_path: Path):
    app = fixture_app(tmp_path)
    target = generate_kubernetes(app, tmp_path / "out")[0]
    report = validate_kubernetes(target)
    assert report.passed, report.findings
    docs = list(yaml.safe_load_all(target.read_text()))
    container = docs[0]["spec"]["template"]["spec"]["containers"][0]
    assert all("valueFrom" in item for item in container["env"])


def test_policy_rejects_privileged_unbounded_workload(tmp_path: Path):
    target = tmp_path / "bad.yaml"
    target.write_text('''apiVersion: apps/v1
kind: Deployment
metadata: {name: unsafe}
spec:
  template:
    spec:
      containers:
        - name: app
          image: unsafe:latest
          securityContext: {privileged: true}
''')
    report = validate_kubernetes(target)
    assert not report.passed
    assert {f.rule_id for f in report.findings} >= {"CF102", "CF103", "CF104", "CF105"}


def test_compose_uses_secret_placeholders(tmp_path: Path):
    app = fixture_app(tmp_path)
    target = generate_local(app, build_proposal(app), tmp_path / "out")[0]
    text = target.read_text()
    assert "POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?set POSTGRES_PASSWORD}" in text
    assert "password" not in text.lower().replace("postgres_password", "")

