from pathlib import Path

from cloudforge.planner import build_proposal
from cloudforge.scanner import RepositoryScanner


def test_local_plan_avoids_kubernetes_for_small_app(tmp_path: Path):
    (tmp_path / "requirements.txt").write_text("fastapi\nredis\n")
    (tmp_path / "main.py").write_text('@app.get("/health")\ndef health(): return {}\n')
    proposal = build_proposal(RepositoryScanner().scan(tmp_path), "local")
    kinds = {resource.kind for resource in proposal.resources}
    assert "docker-compose-service" in kinds
    assert "redis-container" in kinds
    assert "kubernetes-deployment" not in kinds


def test_production_managed_resources_require_approval(tmp_path: Path):
    (tmp_path / "requirements.txt").write_text("fastapi\npsycopg\n")
    proposal = build_proposal(RepositoryScanner().scan(tmp_path), "production")
    database = next(r for r in proposal.resources if r.kind == "managed-postgresql")
    assert database.approval_required

