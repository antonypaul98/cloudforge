from pathlib import Path

from cloudforge.benchmark import benchmark_scan
from cloudforge.slo import SLOObjective, evaluate, evaluate_all


def test_slo_does_not_pass_without_measurement():
    result = evaluate(SLOObjective("availability", ">=", 99.9), None, "no-runtime")
    assert result.status == "insufficient-data"


def test_slo_evaluates_measured_values():
    config = {"objectives": [{"metric": "availability", "operator": ">=", "target": 99.9}, {"metric": "p95_latency_ms", "operator": "<=", "target": 300}]}
    results = evaluate_all(config, {"availability": 99.95, "p95_latency_ms": 184}, "load-test.json")
    assert [r.status for r in results] == ["pass", "pass"]
    assert all(r.source == "load-test.json" for r in results)


def test_scan_benchmark_reports_only_measured_values(tmp_path: Path):
    (tmp_path / "main.py").write_text("print('hello')\n")
    result = benchmark_scan(tmp_path, 3)
    assert result["iterations"] == 3
    assert result["latency_ms"]["min"] >= 0
    assert result["latency_ms"]["max"] >= result["latency_ms"]["min"]

