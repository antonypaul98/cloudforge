# CloudForge

CloudForge is an evidence-first, AI-assisted internal developer platform. It discovers what an application actually requires, proposes the smallest suitable deployment shape, generates reviewable configuration, and verifies policy and runtime outcomes. AI can explain ambiguity; it never silently applies infrastructure.

## Working MVP

```bash
python -m pip install -e .
cloudforge analyze examples/reference-app
cloudforge plan examples/reference-app --profile local
cloudforge generate examples/reference-app --profile kubernetes
cloudforge validate .cloudforge/generated/kubernetes.yaml
cloudforge deploy                       # plan only; no mutation
cloudforge deploy --approve             # explicit local mutation boundary
cloudforge verify --url http://localhost:8000/health
cloudforge benchmark examples/reference-app
```

`analyze` links every important conclusion to deterministic evidence. `plan` never mutates infrastructure. `generate` writes reviewable artifacts. `validate` prints a pass only after YAML parsing and six explicit policy checks execute.

Current implemented scope: Python/FastAPI discovery, PostgreSQL/Redis detection, Docker/port/environment/health discovery, canonical model, evidence provenance, local and production-aware proposals, Docker Compose generation, hardened Kubernetes generation, and built-in policy validation.

The local deployment adapter records command evidence and refuses to apply without approval. Verification and SLO evaluation never convert missing measurements into a pass.

See [PROJECT_STATE.md](PROJECT_STATE.md) for verified status and exact next work.
